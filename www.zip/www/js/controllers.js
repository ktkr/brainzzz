angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope, $interval) {
  $scope.attention = 88;
  $scope.meditation = 40;

  // records start time and calls updateTime and updateData every second/ 3 seconds
  $scope.startSession = function() {
    $scope.sessionOngoing = true;
    $scope.startTime = Date.now();
    timer = $interval($scope.updateTime, 1000);
    data = $interval($scope.updateData, 3215);  
  }
  
  $scope.updateTime = function() {
    // runTime is in seconds
    $scope.runTime = Math.round((Date.now() - $scope.startTime)/1000);
    $scope.runTimeH = Math.floor($scope.runTime/(60*60));
    $scope.runTimeM = Math.floor($scope.runTime/60) - $scope.runTimeH*60;
    $scope.runTimeS = $scope.runTime%60;
  }

  $scope.updateData = function() {
    // INSERT GETTING DATA FROM HEADSET HERE
    $scope.attention -= 5*Math.random();
    $scope.meditation += 5*Math.random();
  }

  $scope.endSession = function() {
    $interval.cancel(timer);
    $interval.cancel(data);
  }
})

.controller('DataCtrl', function ($scope, StudentService) { //added in a DataController to do some basic functions
    $scope.Student = [];
    $scope.input = {};

    function getAllStudents() {
        StudentService.getStudents()
        .then(function (result) {
            $scope.Student = result.data.data;
        });
    }

    $scope.addStudent = function () {
        StudentService.addStudent($scope.input)
        .then(function (result) {
            $scope.input = {};
            // Reload our Students, not super cool
            getAllStudents();
        });
    }

    $scope.deleteStudent = function (id) {
        StudentService.deleteStudent(id)
        .then(function (result) {
            // Reload our Students, not super cool
            getAllStudents();
        });
    }

    getAllStudents();
})

.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
});
