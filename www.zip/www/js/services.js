angular.module('starter.services', [])

.service('StudentService', function ($http, Backand) {
    var baseUrl = '/1/objects/';
    var student = 'Student/';
    //Need to allow toggling between student and Student. Figure this out!!
     // sadadasdasd prob need to summarise this as an entire function
    

  //  var Timestamp = 'Timestamp/';

    function getUrl() {
        return Backand.getApiUrl() + baseUrl + student;
    }

    function getUrlForId(id) {
        return getUrl() + id;
    }

    getStudents = function () {
        return $http.get(getUrl());
    };

    addStudent = function (Student) {
        return $http.post(getUrl(), Student);
    }

    deleteStudent = function (id) {
        return $http.delete(getUrlForId(id));
    };

    return {
        getStudents: getStudents,
        addStudent: addStudent,
        deleteStudent: deleteStudent
    }
})

.factory('Chats', function() {
  // Might use a resource here that returns a JSON array

  var x=5;

  // Some fake testing data
  var chats = [{
    id: 0,
    name: 'Ben Sparrow',
    lastText: 'I\'m so pretty!',
    face: 'img/ben.png'
  }, {
    id: 1,
    name: 'Max Lynx',
    lastText: 'I got the most swag',
    face: 'img/max.png'
  }, {
    id: 2,
    name: 'Adam Bradleyson',
    lastText: 'I\'m on a boat',
    face: 'img/adam.jpg'
  }, {
    id: 3,
    name: 'Perry Governor',
    lastText: 'Get your bananas here!',
    face: 'img/perry.png'
  }, {
    id: 4,
    name: 'Mike Harrington',
    lastText: 'BRAINSSSSSS',
    face: 'img/mike.png'
  }];

  return {
    all: function() {
      return chats;
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(chatId) {
      for (var i = 0; i < chats.length; i++) {
        if (chats[i].id === parseInt(chatId)) {
          return chats[i];
        }
      }
      return null;
    }
  };
});
